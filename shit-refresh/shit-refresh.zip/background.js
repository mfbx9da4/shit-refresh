chrome.browserAction.onClicked.addListener(function(tab) {
 	var action_url = "javascript:localStorage.clear();location.reload();";
 	chrome.tabs.update(tab.id, {url: action_url});
});

chrome.commands.onCommand.addListener(function(command) {
	console.log(command);

	var tab = {}

	chrome.tabs.getCurrent(function (currentTab) {
		tab = currentTab;
	});

	if (command === 'local-storage') {
		var action_url = "javascript:localStorage.clear();location.reload();";
		chrome.tabs.update(tab.id, {url: action_url});
	}
});

